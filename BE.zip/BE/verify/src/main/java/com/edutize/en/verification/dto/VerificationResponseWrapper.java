package com.edutize.en.verification.dto;

public class VerificationResponseWrapper {
	
	private VerificationResponse verificationResponse = new VerificationResponse();

	public VerificationResponse getVerificationResponse() {
		return verificationResponse;
	}

	public void setVerificationResponse(VerificationResponse verificationResponse) {
		this.verificationResponse = verificationResponse;
	}

}
