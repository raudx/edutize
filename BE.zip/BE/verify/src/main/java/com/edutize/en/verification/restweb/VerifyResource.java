package com.edutize.en.verification.restweb;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.edutize.en.verification.dto.VerificationResponse;
import com.edutize.en.verification.dto.VerificationResponseWrapper;
import com.edutize.en.verification.service.VerificationService;

@Path("/")
public class VerifyResource {

    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @return String that will be returned as a text/plain response.
     */
    @GET
    @Path("{verificationId}")
    @Produces(MediaType.APPLICATION_JSON)
    public VerificationResponseWrapper verifyUser(@PathParam("verificationId")String id) {
    	VerificationResponseWrapper responseWrapper = new VerificationResponseWrapper();
    	
    	VerificationService service = new VerificationService();
    	VerificationResponse  response = service.toService(id);
    	responseWrapper.setVerificationResponse(response);
    	return responseWrapper;
    	
    }
    
    @GET
    @Path("vegas")
    @Produces(MediaType.APPLICATION_JSON)
    public VerificationResponseWrapper verifyUser() {
    	VerificationResponseWrapper responseWrapper = new VerificationResponseWrapper();
    	
    	VerificationResponse  response = new VerificationResponse();
    	response.setStatus(true);
    	responseWrapper.setVerificationResponse(response);
    	return responseWrapper;
    	
    }
}
