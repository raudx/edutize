package com.edutize.en.verification.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.edutize.en.encryption.Encrypt;
import com.edutize.en.utilities.DatabaseUtil;
import com.edutize.en.verification.dto.VerificationResponse;

public class VerificationDao {
	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	public VerificationResponse toDao(String id) {
		con = DatabaseUtil.getConnection();
		VerificationResponse response = new VerificationResponse();
		response.setStatus(false);
		String sql = "select login_username, login_created_date_time from edutize_login";
		Encrypt encrypt = new Encrypt();
		try {
			con.setAutoCommit(false);
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next())
			{
				String encryptedLink = encrypt.generateEncryptedText(rs.getString(1)+rs.getString(2));
				if(id.equalsIgnoreCase(encryptedLink))
				{
					sql = "update edutize_login set login_status='ACTIVE' where login_username = ?";
					ps = con.prepareStatement(sql);
					ps.setString(1, rs.getString(1));
					ps.executeUpdate();
					con.commit();
					response.setStatus(true);
					break;
				}
			}
		} catch (SQLException e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		return response;
	}
}
