package com.edutize.en.verification.dto;

public class VerificationResponse {
	
	private boolean status;

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}
	

}
