package com.edutize.en.verification.service;

import com.edutize.en.verification.dao.VerificationDao;
import com.edutize.en.verification.dto.VerificationResponse;

public class VerificationService {

	public VerificationResponse toService(String id) {
		VerificationDao verificationDao = new VerificationDao();
		
		VerificationResponse response = verificationDao.toDao(id);
		return response;
	}

}
