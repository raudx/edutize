package com.edutize.en.ticket.dto;

public class TicketWrapper {

	private Ticket ticket = new Ticket();

	public Ticket getTicket() {
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}

}
