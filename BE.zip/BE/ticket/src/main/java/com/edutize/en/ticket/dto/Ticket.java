package com.edutize.en.ticket.dto;

import java.sql.Date;

import com.edutize.en.ticket.Priority;
import com.edutize.en.ticket.Stage;

public class Ticket {

	private String ticketId;
	private String raisedBy;
	private String subject;
	private String description;
	private Priority priority;
	private String currentlyAssigned;
	private String previouslyAssigned;
	private Date submissionDate;
	private boolean isEscalated;
	private Stage stage;
	private String resolvedBy;
	private String school;

	public String getTicketId() {
		return ticketId;
	}

	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}

	public String getRaisedBy() {
		return raisedBy;
	}

	public void setRaisedBy(String raisedBy) {
		this.raisedBy = raisedBy;
	}

	public Priority getPriority() {
		return priority;
	}

	public void setPriority(Priority priority) {
		this.priority = priority;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCurrentlyAssigned() {
		return currentlyAssigned;
	}

	public void setCurrentlyAssigned(String currentlyAssigned) {
		this.currentlyAssigned = currentlyAssigned;
	}

	public String getPreviouslyAssigned() {
		return previouslyAssigned;
	}

	public void setPreviouslyAssigned(String previouslyAssigned) {
		this.previouslyAssigned = previouslyAssigned;
	}

	public Date getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(Date submissionDate) {
		this.submissionDate = submissionDate;
	}

	public boolean isEscalated() {
		return isEscalated;
	}

	public void setEscalated(boolean isEscalated) {
		this.isEscalated = isEscalated;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public String getResolvedBy() {
		return resolvedBy;
	}

	public void setResolvedBy(String resolvedBy) {
		this.resolvedBy = resolvedBy;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

}
