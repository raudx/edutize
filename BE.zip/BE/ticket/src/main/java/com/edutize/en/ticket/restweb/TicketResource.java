package com.edutize.en.ticket.restweb;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.edutize.en.ticket.dto.Ticket;
import com.edutize.en.ticket.dto.TicketListWrapper;
import com.edutize.en.ticket.dto.TicketWrapper;
import com.edutize.en.ticket.service.TicketService;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("/")
public class TicketResource {

    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @return String that will be returned as a text/plain response.
     */
    @GET
    @Path("{ticketId}")
    @Produces(MediaType.APPLICATION_JSON)
    public TicketWrapper getTicket(@PathParam("ticketId") String ticketId) {
    	TicketWrapper ticketWrapper = new TicketWrapper();
    	TicketService ticketService = new TicketService();
    	Ticket ticket = ticketService.toService(ticketId);
    	ticketWrapper.setTicket(ticket);
        return ticketWrapper;
    }
    
    
    @GET
    @Path("raisedBy/open/{raisedBy}")
    @Produces(MediaType.APPLICATION_JSON)
    public TicketListWrapper getTicketRaisedByOpen(@PathParam("raisedBy") String raisedBy) {
    	TicketListWrapper listWrapper = new TicketListWrapper();
    	TicketService service = new TicketService();
    	List<Ticket> tickets  =  service.toServiceRaisedByOpen(raisedBy);
    	listWrapper.setTickets(tickets);
    	return listWrapper;
    }
    
    @GET
    @Path("raisedBy/closed/{raisedBy}")
    @Produces(MediaType.APPLICATION_JSON)
    public TicketListWrapper getTicketRaisedByClosed(@PathParam("raisedBy") String raisedBy) {
    	TicketListWrapper listWrapper = new TicketListWrapper();
    	TicketService service = new TicketService();
    	List<Ticket> tickets  =  service.toServiceRaisedByClosed(raisedBy);
    	listWrapper.setTickets(tickets);
    	return listWrapper;
    }
    
    @GET
    @Path("assignedTo/open/{assignedTo}")
    @Produces(MediaType.APPLICATION_JSON)
    public TicketListWrapper getTicketAssignedToOpen(@PathParam("assignedTo") String assignedTo) {
    	TicketListWrapper listWrapper = new TicketListWrapper();
    	TicketService service = new TicketService();
    	List<Ticket> tickets  =  service.toServiceAssignedToOpen(assignedTo);
    	listWrapper.setTickets(tickets);
    	return listWrapper;
    }
    
    @GET
    @Path("assignedTo/closed/{assignedTo}")
    @Produces(MediaType.APPLICATION_JSON)
    public TicketListWrapper getTicketAssignedToClosed(@PathParam("assignedTo") String assignedTo) {
    	TicketListWrapper listWrapper = new TicketListWrapper();
    	TicketService service = new TicketService();
    	List<Ticket> tickets  =  service.toServiceAssignedToClosed(assignedTo);
    	listWrapper.setTickets(tickets);
    	return listWrapper;
    }
    
    @PUT
    @Path("student")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public TicketWrapper logTicketStudent(TicketWrapper ticketWrapper)
    {
    	TicketWrapper ticketWrapperResult = new TicketWrapper();
    	TicketService service = new TicketService();
    	Ticket ticket = service.toLogTicketService(ticketWrapper.getTicket());
    	ticketWrapperResult.setTicket(ticket);
    	return ticketWrapperResult;
    }
    
    @PUT
    @Path("faculty")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public TicketWrapper logTicketFaculty(TicketWrapper ticketWrapper)
    {
    	TicketWrapper ticketWrapperResult = new TicketWrapper();
    	TicketService service = new TicketService();
    	Ticket ticket = service.toLogTicketFacultyService(ticketWrapper.getTicket());
    	ticketWrapperResult.setTicket(ticket);
    	return ticketWrapperResult;
    }
    
    
}
