package com.edutize.en.ticket.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response.Status;

import com.edutize.en.exception.GenericException;
import com.edutize.en.ticket.Priority;
import com.edutize.en.ticket.Stage;
import com.edutize.en.ticket.dto.Ticket;
import com.edutize.en.utilities.DatabaseUtil;

public class TicketDao {

	public Ticket toDao(String ticketId) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = null;
		Ticket ticket = new Ticket();
		con = DatabaseUtil.getConnection();
		if (con != null) {
			sql = "select * from edutize_ticket where ticket_id = ? and ticket_stage != 'CLOSED'";
			try {
				ps = con.prepareStatement(sql);
				ps.setString(1, ticketId);
				rs = ps.executeQuery();
				if (rs.next()) {
					ticket.setTicketId(ticketId);
					ticket.setRaisedBy(rs.getString(2));
					ticket.setSubject(rs.getString(3));
					ticket.setDescription(rs.getString(4));
					ticket.setPriority(Priority.valueOf(rs.getString(5)));
					ticket.setCurrentlyAssigned(rs.getString(6));
					ticket.setPreviouslyAssigned(rs.getString(7));
					ticket.setSubmissionDate(rs.getDate(8));
					ticket.setEscalated(rs.getBoolean(9));
					ticket.setStage(Stage.valueOf(rs.getString(10)));
					ticket.setResolvedBy(rs.getString(11));
					ticket.setSchool(rs.getString(12));
				} else {
					throw new GenericException(Status.BAD_REQUEST, "No such ticket exist");
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "Sql exception occured");
			}
		}
		return ticket;
	}

	public List<Ticket> toDaoRaisedByOpen(String raisedBy) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = null;
		List<Ticket> tickets = new ArrayList<Ticket>();
		Ticket ticket = null;
		con = DatabaseUtil.getConnection();
		if (con != null) {
			sql = "select * from edutize_ticket where ticket_raisedBy = ? and ticket_stage != 'CLOSED'";
			try {
				ps = con.prepareStatement(sql);
				ps.setString(1, raisedBy);
				rs = ps.executeQuery();
				while (rs.next()) {
					ticket = new Ticket();
					ticket.setTicketId(rs.getString(1));
					ticket.setSubject(rs.getString(3));
					ticket.setPriority(Priority.valueOf(rs.getString(5)));
					ticket.setSubmissionDate(rs.getDate(8));
					ticket.setEscalated(rs.getBoolean(9));
					ticket.setStage(Stage.valueOf(rs.getString(10)));
					tickets.add(ticket);
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "Sql exception occured");
			}
		}
		return tickets;
	}

	public List<Ticket> toDaoRaisedByClosed(String raisedBy) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = null;
		List<Ticket> tickets = new ArrayList<Ticket>();
		Ticket ticket = null;
		con = DatabaseUtil.getConnection();
		if (con != null) {
			sql = "select * from edutize_ticket where ticket_raisedBy = ? and ticket_stage = 'CLOSED'";
			try {
				ps = con.prepareStatement(sql);
				ps.setString(1, raisedBy);
				rs = ps.executeQuery();
				while (rs.next()) {
					ticket = new Ticket();
					ticket.setTicketId(rs.getString(1));
					ticket.setSubject(rs.getString(3));
					ticket.setPriority(Priority.valueOf(rs.getString(5)));
					ticket.setSubmissionDate(rs.getDate(8));
					ticket.setEscalated(rs.getBoolean(9));
					ticket.setStage(Stage.valueOf(rs.getString(10)));
					ticket.setResolvedBy(rs.getString(11));
					tickets.add(ticket);
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "Sql exception occured");
			}
		}
		return tickets;
	}

	public List<Ticket> toDaoAssignedToOpen(String assignedTo) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = null;
		List<Ticket> tickets = new ArrayList<Ticket>();
		Ticket ticket = null;
		con = DatabaseUtil.getConnection();
		if (con != null) {
			sql = "select * from edutize_ticket where ticket_currentlyAssigned = ? and ticket_stage != 'CLOSED'";
			try {
				ps = con.prepareStatement(sql);
				ps.setString(1, assignedTo);
				rs = ps.executeQuery();
				while (rs.next()) {
					ticket = new Ticket();
					ticket.setTicketId(rs.getString(1));
					ticket.setSubject(rs.getString(3));
					ticket.setPriority(Priority.valueOf(rs.getString(5)));
					ticket.setSubmissionDate(rs.getDate(8));
					ticket.setEscalated(rs.getBoolean(9));
					ticket.setStage(Stage.valueOf(rs.getString(10)));
					tickets.add(ticket);
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "Sql exception occured");
			}
		}
		return tickets;
	}

	public List<Ticket> toDaoAssignedToClosed(String assignedTo) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = null;
		List<Ticket> tickets = new ArrayList<Ticket>();
		Ticket ticket = null;
		con = DatabaseUtil.getConnection();
		if (con != null) {
			sql = "select * from edutize_ticket where ticket_currentlyAssigned = ? and ticket_stage = 'CLOSED'";
			try {
				ps = con.prepareStatement(sql);
				ps.setString(1, assignedTo);
				rs = ps.executeQuery();
				while (rs.next()) {
					ticket = new Ticket();
					ticket.setTicketId(rs.getString(1));
					ticket.setSubject(rs.getString(3));
					ticket.setPriority(Priority.valueOf(rs.getString(5)));
					ticket.setSubmissionDate(rs.getDate(8));
					ticket.setEscalated(rs.getBoolean(9));
					ticket.setStage(Stage.valueOf(rs.getString(10)));
					ticket.setResolvedBy(rs.getString(11));
					tickets.add(ticket);
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "Sql exception occured");
			}
		}
		return tickets;
	}

	public Ticket toLogTicketDao(Ticket ticket) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = null;
		List<Ticket> tickets = new ArrayList<Ticket>();
		Ticket ticketResult = new Ticket();
		String classes = null;
		String section = null;
		String facId = null;
		con = DatabaseUtil.getConnection();
		if (con != null) {
			sql = "select student_profile_class, student_profile_section from edutize_student_profile where student_profile_empId = ? ";
			try {
				ps = con.prepareStatement(sql);
				ps.setString(1, ticket.getRaisedBy());
				rs = ps.executeQuery();
				if (rs.next()) {
					classes = rs.getString(1);
					section = rs.getString(2);
				} else {
					throw new GenericException(Status.BAD_REQUEST, "No such data exist");
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "Sql exception occured");
			}

			sql = "select profile_empId from edutize_profile where profile_class = ? and profile_section = ? and profile_institute = ?";
			try {
				ps = con.prepareStatement(sql);
				ps.setString(1, classes);
				ps.setString(2, section);
				ps.setString(3, ticket.getSchool());
				rs = ps.executeQuery();
				if (rs.next()) {
					facId = rs.getString(1);
				} else {
					throw new GenericException(Status.BAD_REQUEST, "No such data exist");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "Sql exception occured");
			}

			sql = "insert into edutize_ticket (ticket_raisedBy, ticket_subject, ticket_description, ticket_priority,ticket_currentlyAssigned,school) values (?, ?, ?, ?, ?, ?)";
			try {
				con.setAutoCommit(false);
				ps = con.prepareStatement(sql);
				ps.setString(1, ticket.getRaisedBy());
				ps.setString(2, ticket.getSubject());
				ps.setString(3, ticket.getDescription());
				ps.setString(4, ticket.getPriority().toString());
				ps.setString(5, facId);
				ps.setString(6, ticket.getSchool());
				ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				con.commit();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			sql = "select max(ticket_id) from edutize_ticket";
			try {
				ps = con.prepareStatement(sql);
				rs = ps.executeQuery();
				if (rs.next()) {
					ticketResult.setTicketId(rs.getString(1));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return ticketResult;
	}

	public Ticket toLogTicketFacultyDao(Ticket ticket) {
		
		return null;
	}
}
