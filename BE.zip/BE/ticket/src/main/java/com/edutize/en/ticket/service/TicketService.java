package com.edutize.en.ticket.service;

import java.util.List;

import com.edutize.en.ticket.dao.TicketDao;
import com.edutize.en.ticket.dto.Ticket;

public class TicketService {

	public Ticket toService(String ticketId) {
		TicketDao ticketDao = new TicketDao();
		Ticket ticket = ticketDao.toDao(ticketId);
		return ticket;
	}

	public List<Ticket> toServiceRaisedByOpen(String raisedBy) {
		TicketDao ticketDao = new TicketDao();
		List<Ticket> tickets = ticketDao.toDaoRaisedByOpen(raisedBy);
		return tickets;
	}
	
	public List<Ticket> toServiceRaisedByClosed(String raisedBy) {
		TicketDao ticketDao = new TicketDao();
		List<Ticket> tickets = ticketDao.toDaoRaisedByClosed(raisedBy);
		return tickets;
	}

	public List<Ticket> toServiceAssignedToOpen(String assignedTo) {
		TicketDao ticketDao = new TicketDao();
		List<Ticket> tickets = ticketDao.toDaoAssignedToOpen(assignedTo);
		return tickets;
	}
	
	public List<Ticket> toServiceAssignedToClosed(String assignedTo) {
		TicketDao ticketDao = new TicketDao();
		List<Ticket> tickets = ticketDao.toDaoAssignedToClosed(assignedTo);
		return tickets;
	}

	public Ticket toLogTicketService(Ticket ticket) {
		TicketDao ticketDao = new TicketDao();
		Ticket ticketResult = ticketDao.toLogTicketDao(ticket);
		return ticketResult;
	}

	public Ticket toLogTicketFacultyService(Ticket ticket) {
		TicketDao ticketDao = new TicketDao();
		Ticket ticketResult = ticketDao.toLogTicketFacultyDao(ticket);
		return ticketResult;
	}
}
