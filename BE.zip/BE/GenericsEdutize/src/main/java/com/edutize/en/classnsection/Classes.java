package com.edutize.en.classnsection;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Response.Status;

import com.edutize.en.exception.GenericException;

public enum Classes {
	LKG("LKG"), UKG("UKG"), I("I"), II("II"), III("III"), IV("IV"), V("V"), VI("VI"), VII("VII"), VIII("VIII"), IX(
			"IX"), X("X"), XI("XI"), XII("XII");

	private String value;

	private static Map<String, Classes> map = new HashMap<String, Classes>();

	static {
		for (Classes c : Classes.values()) {
			map.put(c.value, c);
		}
	}

	private Classes(String value) {
		this.value = value;
	}

	public Classes getValue(String value) {
		if (map.containsKey(value)) {
			return map.get(value);
		} else {
			throw new GenericException(Status.BAD_REQUEST, "No proper of value of Ennumeration initialised");
		}
	}

}
