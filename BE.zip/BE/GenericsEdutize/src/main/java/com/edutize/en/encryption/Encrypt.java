package com.edutize.en.encryption;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.ws.rs.core.Response.Status;

import com.edutize.en.exception.GenericException;

public class Encrypt {

	public String generateEncryptedText(String username) {
		String encryptedPassword = null;
		try {
			final MessageDigest messageDigest = MessageDigest.getInstance("MD5");
			messageDigest.update(username.getBytes(), 0, username.length());
			BigInteger i = new BigInteger(1, messageDigest.digest());
			encryptedPassword = String.format("%1$032x", i);
		} catch (NoSuchAlgorithmException e) {
			throw new GenericException(Status.BAD_REQUEST, "Algorithm not recognised");
		}
		return encryptedPassword;
	}
}
