package com.edutize.en.profile;

public enum MaritialStatus {

}
