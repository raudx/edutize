package com.edutize.en.profile;

public enum BloodGroup {

}
