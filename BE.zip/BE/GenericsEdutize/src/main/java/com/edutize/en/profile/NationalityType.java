package com.edutize.en.profile;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Response.Status;

import com.edutize.en.exception.GenericException;

public enum NationalityType {

	INDIA("INDIA");

	private String value;

	private static Map<String, NationalityType> map = new HashMap<String, NationalityType>();

	static {
		for (NationalityType nationalityType : NationalityType.values()) {
			map.put(nationalityType.value, nationalityType);
		}
	}

	private NationalityType(String value) {
		this.value = value;
	}

	public NationalityType getValue(String value) throws GenericException {
		if (value == null) {
			throw new GenericException(Status.BAD_REQUEST, "Uninitialised value of enum");
		} else if (map.containsKey(value)) {
			return map.get(value);
		} else {
			return null;
		}
	}

}
