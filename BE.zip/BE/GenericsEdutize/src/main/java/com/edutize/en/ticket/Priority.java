package com.edutize.en.ticket;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Response.Status;

import com.edutize.en.exception.GenericException;

public enum Priority {
	HIGH("HIGH"), MEDIUM("MEDIUM"), LOW("LOW");

	private String value;
	private static Map<String, Priority> map = new HashMap<String, Priority>();
	static {
		for (Priority priority : Priority.values()) {
			map.put(priority.value, priority);
		}
	}

	private Priority(String value) {
		this.value = value;
	}

	public Priority getValue(String value) throws GenericException {
		if (value == null) {
			throw new GenericException(Status.BAD_REQUEST, "Uninitialised value of enum");
		} else if (map.containsKey(value)) {
			return map.get(value);
		} else {
			return null;
		}
	}

}
