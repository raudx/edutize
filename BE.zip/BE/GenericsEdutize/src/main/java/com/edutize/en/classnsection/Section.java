package com.edutize.en.classnsection;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Response.Status;

import com.edutize.en.exception.GenericException;

public enum Section {
	A("A"),B("B"),C("C"),D("D"),E("E"),F("F"),G("G");

	private String value;

	private static Map<String, Section> map = new HashMap<String, Section>();

	static {
		for (Section c : Section.values()) {
			map.put(c.value, c);
		}
	}

	private Section(String value) {
		this.value = value;
	}

	public Section getValue(String value) {
		if (map.containsKey(value)) {
			return map.get(value);
		} else {
			throw new GenericException(Status.BAD_REQUEST, "No proper of value of Ennumeration initialised");
		}
	}


}
