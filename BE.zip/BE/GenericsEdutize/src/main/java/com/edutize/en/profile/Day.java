package com.edutize.en.profile;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Response.Status;

import com.edutize.en.exception.GenericException;

public enum Day {
	
	MONDAY("MONDAY"),TUESDAY("TUESDAY"),WEDNESDAY("WEDNESDAY"),
	THRUSDAY("THRUSDAY"), FRIDAY("FRIDAY"), SATURDAY("SATURDAY"),SUNDAY("SUNDAY");
	
	private String value;
	
	private static Map<String, Day> map = new HashMap<String, Day>();
	
	static
	{
		for(Day day: Day.values())
		{
			map.put(day.value, day);
		}
	}
	private Day(String value)
	{
		this.value = value;
	}
	
	public Day getValue(String value) throws GenericException {
		if (value == null) {
			throw new GenericException(Status.BAD_REQUEST, "Uninitialised value of enum");
		} else if (map.containsKey(value)) {
			return map.get(value);
		} else {
			return null;
		}
	}
	
	

}
