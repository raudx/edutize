package com.edutize.en.profile;

public enum Domicile {
	ANDHRAPRADESH("ANDHRAPRADESH");
	
	private Domicile(String value)
	{
		
	}

}
