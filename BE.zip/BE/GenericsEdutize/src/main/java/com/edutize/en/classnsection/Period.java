package com.edutize.en.classnsection;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Response.Status;

import com.edutize.en.exception.GenericException;

public enum Period {
	I("I"), II("II"), III("III"), IV("IV"), V("V"), VI("VI"), VII("VII"), VIII("VIII"), IX(
			"IX"), X("X");
	
	private String value;

	private static Map<String, Period> map = new HashMap<String, Period>();

	static {
		for (Period c : Period.values()) {
			map.put(c.value, c);
		}
	}

	private Period(String value) {
		this.value = value;
	}

	public Period getValue(String value) {
		if (map.containsKey(value)) {
			return map.get(value);
		} else {
			throw new GenericException(Status.BAD_REQUEST, "No proper of value of Ennumeration initialised");
		}
	}

}
