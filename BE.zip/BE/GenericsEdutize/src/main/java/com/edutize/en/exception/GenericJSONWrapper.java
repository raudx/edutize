package com.edutize.en.exception;

public class GenericJSONWrapper {

	private GenericJSON exception = new GenericJSON();

	public GenericJSONWrapper() {

	}

	public GenericJSONWrapper(GenericJSON exception) {
		this.exception = exception;
	}

	public GenericJSON getException() {
		return exception;
	}

	public void setException(GenericJSON exception) {
		this.exception = exception;
	}

}
