package com.edutize.en.designationType;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Response.Status;

import com.edutize.en.exception.GenericException;

public enum DesignationType {

	ADMIN("ADMIN"), MANAGEMENT("MANAGEMENT"), FACULTY("FACULTY"), STUDENT("STUDENT"), UNKNOWN("UNKNOWN");

	private String value;

	private static Map<String, DesignationType> map = new HashMap<String, DesignationType>();

	static {
		for (DesignationType designationType : DesignationType.values()) {
			map.put(designationType.value, designationType);
		}
	}

	private DesignationType(String value) {
		this.value = value;
	}

	public DesignationType getValue(String value) {
		if (!map.containsKey(value)) {
			throw new GenericException(Status.BAD_REQUEST, "Designation type not valid");
		} else {
			return (map.get(value));
		}
	}

}
