package com.edutize.en.exception;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

public class GenericException extends WebApplicationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public GenericException(Status status, String message) {
		super(Response.status(status.getStatusCode()).entity(new GenericJSONWrapper(new GenericJSON(status, message))).type("application/json").build());
	}

}
