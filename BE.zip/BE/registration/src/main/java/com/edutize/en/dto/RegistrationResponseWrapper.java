package com.edutize.en.dto;

public class RegistrationResponseWrapper {

	RegistrationResponse registrationResponse = new RegistrationResponse();

	public RegistrationResponse getRegistrationResponse() {
		return registrationResponse;
	}

	public void setRegistrationResponse(RegistrationResponse registrationResponse) {
		this.registrationResponse = registrationResponse;
	}

}
