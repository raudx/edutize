package com.edutize.en.dto;

public class StudentWrapper {

	private Student register = new Student();

	public Student getRegister() {
		return register;
	}

	public void setRegister(Student register) {
		this.register = register;
	}
}
