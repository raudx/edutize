package com.edutize.en.dto;

import com.edutize.en.designationType.DesignationType;

public class RegistrationResponse {

	private String verificationURL;
	private DesignationType type;

	public String getVerificationURL() {
		return verificationURL;
	}

	public void setVerificationURL(String verificationURL) {
		this.verificationURL = verificationURL;
	}

	public DesignationType getType() {
		return type;
	}

	public void setType(DesignationType type) {
		this.type = type;
	}

}
