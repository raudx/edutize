package com.edutize.en.registration.restweb;

import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.edutize.en.dto.Registration;
import com.edutize.en.dto.RegistrationResponse;
import com.edutize.en.dto.RegistrationResponseWrapper;
import com.edutize.en.dto.RegistrationWrapper;
import com.edutize.en.registration.businesslayer.RegistrationService;

@Path("/")
public class RegistrationResource {

	/**
	 * This method receives registration details of management and faculty and stores it to data source
	 * @param registrationDetails contains registration info from 
	 * @return returns a status and username for registration
	 */
	@PUT
	@Path("register")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public RegistrationResponseWrapper getIt(RegistrationWrapper registrationDetails) {
		Registration registration = registrationDetails.getRegister();
		RegistrationService service = new RegistrationService();
		RegistrationResponseWrapper responseWrapper = new RegistrationResponseWrapper();
		RegistrationResponse registrationResponse = service.toService(registration);
		responseWrapper.setRegistrationResponse(registrationResponse);
		return responseWrapper;
	}
	
	/*@PUT
	@Path("student")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public RegistrationResponseWrapper registerStudent(StudentWrapper registrationDetails)
	{
		Student registration = registrationDetails.getRegister();
		RegistrationService service = new RegistrationService();
		RegistrationResponseWrapper responseWrapper = new RegistrationResponseWrapper();
		RegistrationResponse registrationResponse = service.toServiceStudent(registration);
		responseWrapper.setRegistrationResponse(registrationResponse);
		return responseWrapper;
	}*/
	

	
}
