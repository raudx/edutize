package com.edutize.en.dto;

public class RegistrationWrapper {
	
	private Registration register = new Registration();

	public Registration getRegister() {
		return register;
	}

	public void setRegister(Registration register) {
		this.register = register;
	}

}
