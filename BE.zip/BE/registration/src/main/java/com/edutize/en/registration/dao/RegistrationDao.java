package com.edutize.en.registration.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.ws.rs.core.Response.Status;

import com.edutize.en.dto.Registration;
import com.edutize.en.dto.RegistrationResponse;
import com.edutize.en.encryption.Encrypt;
import com.edutize.en.exception.GenericException;
import com.edutize.en.utilities.DatabaseUtil;

public class RegistrationDao {

	public static RegistrationResponse toDao(Registration registration) {
		RegistrationResponse response = new RegistrationResponse();

		Connection con = null;
		PreparedStatement ps = null;
		String generatedURL = "http://localhost:8081/verify/";
		String sql = null;
		ResultSet rs = null;
		con = DatabaseUtil.getConnection();

		if (con != null) {
			try {
				con.setAutoCommit(false);
				sql = "insert into edutize_login (login_username, login_password, login_type) values (?,?, ?)";
				ps = con.prepareStatement(sql);
				ps.setString(1, registration.getEmail());
				ps.setString(2, registration.getPassword());
				ps.setString(3, registration.getDesignation().toString());

				int res = ps.executeUpdate();
				if (res > 0) {
					sql = "insert into edutize_profile (profile_username, profile_empId, profile_firstName, profile_middleName, profile_lastName, profile_institute, profile_dob, profile_gender) values (?, ?, ?, ?, ?,?,?,?)";
					ps = con.prepareStatement(sql);
					ps.setString(1, registration.getEmail());
					ps.setString(2, registration.getEmpId());
					ps.setString(3, registration.getFirstname());
					if (registration.getMiddleName() == null) {
						ps.setString(4, "NA");
					} else {
						ps.setString(4, registration.getMiddleName());
					}
					ps.setString(5, registration.getLastname());
					ps.setString(6, registration.getInstitute());
					ps.setDate(7, registration.getDob());
					ps.setString(8, registration.getGender());
					res = ps.executeUpdate();
					con.commit();
				}

			} catch (SQLException e) {
				try {
					e.printStackTrace();
					con.rollback();
					throw new GenericException(Status.INTERNAL_SERVER_ERROR,
							"Not able to perform regisration. Rollback performed successfully");
				} catch (SQLException e1) {
					throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Not able to perform rollback");
				}
			}
		} else {
			throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Connection to database cannot be established");
		}
		Encrypt encrypt = new Encrypt();
		String timestamp = null;
		sql = "select login_created_date_time from edutize_login where login_username = ?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, registration.getUsername());
			rs = ps.executeQuery();
			if (rs.next()) {
				timestamp = rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		generatedURL = generatedURL + encrypt.generateEncryptedText(registration.getUsername() + timestamp);
		response.setVerificationURL(generatedURL);
		response.setType(registration.getDesignation());
		return response;
	}

	public static RegistrationResponse toDaoStudent(Registration registration) {
		RegistrationResponse response = new RegistrationResponse();

		Connection con = null;
		PreparedStatement ps = null;
		String generatedURL = "http://localhost:8081/verify/";
		String sql = null;
		ResultSet rs = null;
		con = DatabaseUtil.getConnection();

		if (con != null) {
			try {
				con.setAutoCommit(false);
				sql = "insert into edutize_login (login_username, login_password, login_type) values (?,?, ?)";
				ps = con.prepareStatement(sql);
				ps.setString(1, registration.getEmail());
				ps.setString(2, registration.getPassword());
				ps.setString(3, registration.getDesignation().toString());

				int res = ps.executeUpdate();
				if (res > 0) {
					sql = "insert into edutize_student_profile (student_profile_username, student_profile_empId, student_profile_firstName, student_profile_middleName, student_profile_lastName, student_profile_institute, student_profile_dob, student_profile_gender,student_profile_class, student_profile_section) values (?, ?, ?, ?, ?,?,?,?,?,?)";
					ps = con.prepareStatement(sql);
					ps.setString(1, registration.getEmail());
					ps.setString(2, registration.getEmpId());
					ps.setString(3, registration.getFirstname());
					if (registration.getMiddleName() == null) {
						ps.setString(4, "NA");
					} else {
						ps.setString(4, registration.getMiddleName());
					}
					ps.setString(5, registration.getLastname());
					ps.setString(6, registration.getInstitute());
					ps.setDate(7, registration.getDob());
					ps.setString(8, registration.getGender());
					ps.setString(9, registration.getClasses().toString());
					ps.setString(10, registration.getSection().toString());
					res = ps.executeUpdate();
					con.commit();
				}

			} catch (SQLException e) {
				try {
					e.printStackTrace();
					con.rollback();
					throw new GenericException(Status.INTERNAL_SERVER_ERROR,
							"Not able to perform regisration. Rollback performed successfully");
				} catch (SQLException e1) {
					throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Not able to perform rollback");
				}
			}
		} else {
			throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Connection to database cannot be established");
		}
		Encrypt encrypt = new Encrypt();
		String timestamp = null;
		sql = "select login_created_date_time from edutize_login where login_username = ?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, registration.getUsername());
			rs = ps.executeQuery();
			if (rs.next()) {
				timestamp = rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		generatedURL = generatedURL + encrypt.generateEncryptedText(registration.getUsername() + timestamp);
		response.setVerificationURL(generatedURL);
		response.setType(registration.getDesignation());;
		return response;
	}

}
