package com.edutize.en.registration.businesslayer;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.ws.rs.core.Response.Status;

import com.edutize.en.designationType.DesignationType;
import com.edutize.en.dto.Registration;
import com.edutize.en.dto.RegistrationResponse;
import com.edutize.en.exception.GenericException;
import com.edutize.en.registration.dao.RegistrationDao;

public class RegistrationService {

	public RegistrationResponse toService(Registration registration) {
		// encrypting paasword using MD5
		String password = registration.getPassword();
		String encPassword = encryptPassword(password);
		RegistrationResponse response;
		registration.setPassword(encPassword);
		if (registration.getDesignation().equals(DesignationType.STUDENT)) {
			response = RegistrationDao.toDaoStudent(registration);
		} else {
			response = RegistrationDao.toDao(registration);
		}

		return response;
	}

	/*
	 * public RegistrationResponse toServiceStudent(Student registration) {
	 * //encrypting paasword using MD5 String password =
	 * registration.getPassword(); String encPassword =
	 * encryptPassword(password); registration.setPassword(encPassword);
	 * RegistrationResponse response =
	 * RegistrationDao.toDaoStudent(registration); return response; }
	 */

	private String encryptPassword(String password) {
		String encryptedPassword = null;
		try {
			final MessageDigest messageDigest = MessageDigest.getInstance("MD5");
			messageDigest.update(password.getBytes(), 0, password.length());
			BigInteger i = new BigInteger(1, messageDigest.digest());
			encryptedPassword = String.format("%1$032x", i);
		} catch (NoSuchAlgorithmException e) {
			throw new GenericException(Status.BAD_REQUEST, "Algorithm not recognised");
		}
		return encryptedPassword;
	}

}
