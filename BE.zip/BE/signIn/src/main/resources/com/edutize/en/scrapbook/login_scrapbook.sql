create table edutize_login(
login_username varchar(30) PRIMARY KEY,
login_password varchar(100) NOT NULL,
login_type varchar(15) NOT NULL,
login_status varchar(10),
login_created_date date,
login_created_time time
);

drop table edutize_login;

select * from edutize_login;

select login_type from edutize_login where login_username = 'raudx' and login_password = '77688Zh9' ;

insert into edutize_login (login_username, login_password, login_type, login_status)
	values ("raudx","77688Zh9","ADMIN","ACTIVE");