package com.edutize.en.login.restweb;

import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.edutize.en.designationType.DesignationType;
import com.edutize.en.login.businesslayer.SigningServices;
import com.edutize.en.login.dto.SignIn;
import com.edutize.en.login.dto.SignInWrapper;
import com.edutize.en.login.dto.SigningResponse;
import com.edutize.en.login.dto.SigningResponseWrapper;

@Path("/")
public class SingInResource {

    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @return String that will be returned as a text/plain response.
     */
    @PUT
    @Path("in")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public SigningResponseWrapper getIt(SignInWrapper signInWrapper) {
        SignIn signIn = signInWrapper.getSignin();
        SigningServices signingServices = new SigningServices();
        DesignationType status = signingServices.toService(signIn);
    	SigningResponseWrapper responseWrapper = new SigningResponseWrapper();
        SigningResponse response = new SigningResponse();
        response.setType(status);
        responseWrapper.setSigningresponse(response);
        return responseWrapper;
    }
}
