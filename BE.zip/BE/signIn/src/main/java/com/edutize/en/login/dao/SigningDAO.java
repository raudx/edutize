package com.edutize.en.login.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.ws.rs.core.Response.Status;

import com.edutize.en.designationType.DesignationType;
import com.edutize.en.exception.GenericException;
import com.edutize.en.login.dto.SignIn;
import com.edutize.en.utilities.DatabaseUtil;

public class SigningDAO {

	public DesignationType toDAO(SignIn signIn) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		DesignationType designationType = DesignationType.UNKNOWN;
		String status = null;
		con = DatabaseUtil.getConnection();
		if (con != null) {
			String sql = "select login_type, login_status from edutize_login where login_username =? and login_password =?";
			try {
				ps = con.prepareStatement(sql);
				ps.setString(1, signIn.getUsername());
				ps.setString(2, signIn.getPassword());
				rs = ps.executeQuery();
				while (rs.next()) {
					designationType = DesignationType.valueOf(rs.getString(1));
					status = rs.getString(2);
					if (!status.equalsIgnoreCase("ACTIVE")) {
						throw new GenericException(Status.BAD_REQUEST,
								"Your account is " + rs.getString(2).toLowerCase() + ". Please contact administrator.");
					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "Not able to fetch data from database");
			}
		} else {
			throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Database down. Please try after sometime");
		}
		return designationType;
	}

}
