package com.edutize.en.login.dto;

public class SigningResponseWrapper {

	private SigningResponse signingresponse = new SigningResponse();

	public SigningResponse getSigningresponse() {
		return signingresponse;
	}

	public void setSigningresponse(SigningResponse signingresponse) {
		this.signingresponse = signingresponse;
	}

}
