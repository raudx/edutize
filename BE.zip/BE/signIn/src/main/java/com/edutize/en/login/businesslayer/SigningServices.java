package com.edutize.en.login.businesslayer;

import com.edutize.en.designationType.DesignationType;
import com.edutize.en.encryption.Encrypt;
import com.edutize.en.login.dao.SigningDAO;
import com.edutize.en.login.dto.SignIn;

public class SigningServices {

	public DesignationType toService(SignIn signIn) {
		SigningDAO signingDAO = new SigningDAO();
		Encrypt encrypt = new Encrypt();
		String encryptedText = encrypt.generateEncryptedText(signIn.getPassword());
		signIn.setPassword(encryptedText);
		DesignationType status = signingDAO.toDAO(signIn);
		return status;
	}

}
