package com.edutize.en.login.dto;

public class SignInWrapper {

	private SignIn signin = new SignIn();

	public SignIn getSignin() {
		return signin;
	}

	public void setSignin(SignIn signin) {
		this.signin = signin;
	}

}
