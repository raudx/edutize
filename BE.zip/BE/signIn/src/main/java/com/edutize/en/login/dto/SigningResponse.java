package com.edutize.en.login.dto;

import com.edutize.en.designationType.DesignationType;

public class SigningResponse {

	private DesignationType type;

	public DesignationType getType() {
		return type;
	}

	public void setType(DesignationType type) {
		this.type = type;
	}

}
