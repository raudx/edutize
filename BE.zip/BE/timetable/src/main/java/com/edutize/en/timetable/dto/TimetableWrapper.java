package com.edutize.en.timetable.dto;

import java.util.ArrayList;
import java.util.List;

import com.edutize.en.classnsection.Classes;
import com.edutize.en.classnsection.Section;

public class TimetableWrapper {

	private String facId;
	private boolean isClassTeacher;
	private Classes classes;
	private Section section;
	private List<Timetable> timetable = new ArrayList<Timetable>();

	public String getFacId() {
		return facId;
	}

	public void setFacId(String facId) {
		this.facId = facId;
	}

	public boolean isClassTeacher() {
		return isClassTeacher;
	}

	public void setClassTeacher(boolean isClassTeacher) {
		this.isClassTeacher = isClassTeacher;
	}

	public Classes getClasses() {
		return classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	public Section getSection() {
		return section;
	}

	public void setSection(Section section) {
		this.section = section;
	}

	public List<Timetable> getTimetable() {
		return timetable;
	}

	public void setTimetable(List<Timetable> timetable) {
		this.timetable = timetable;
	}

}
