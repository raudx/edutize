package com.edutize.en.timetable.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response.Status;

import com.edutize.en.classnsection.Classes;
import com.edutize.en.classnsection.Period;
import com.edutize.en.classnsection.Section;
import com.edutize.en.exception.GenericException;
import com.edutize.en.profile.Day;
import com.edutize.en.timetable.dto.Timetable;
import com.edutize.en.timetable.dto.TimetableResponse;
import com.edutize.en.timetable.dto.TimetableWrapper;
import com.edutize.en.utilities.DatabaseUtil;

public class TimetableDao {

	public TimetableResponse toDao(TimetableWrapper timetableWrapper) {
		Connection con = null;
		PreparedStatement ps = null;
		String sql = null;
		TimetableResponse response = new TimetableResponse();
		response.setSuccess(false);
		con = DatabaseUtil.getConnection();
		if (con != null) {
			if(timetableWrapper.isClassTeacher())
			{
				
				try {
					con.setAutoCommit(false);
					sql = "insert into edutize_profile (profile_role, profile_class, profile_section) values (\"CLASS_TEACHER\", ?, ?)";
					ps = con.prepareStatement(sql);
					ps.setString(1, timetableWrapper.getClass().toString());
					ps.setString(2, timetableWrapper.getClasses().toString());
					ps.executeUpdate();
				} catch (SQLException e) {
					e.printStackTrace();
					throw new GenericException(Status.BAD_REQUEST, "Some error occured in SQL");
				}
				
			}
			for (Timetable temp : timetableWrapper.getTimetable()) {
				if (temp.getDay().equals(Day.MONDAY)) {
					sql = "insert into edutize_timetable_monday (timetable_monday_facId,timetable_monday_period,timetable_monday_class,timetable_monday_section,timetable_monday_subject, school) values (?, ?, ?, ?, ?, ?)";
					try {
						ps = con.prepareStatement(sql);
						ps.setString(1, timetableWrapper.getFacId());
						ps.setString(2, temp.getPeriod().toString());
						ps.setString(3, temp.getClasses().toString());
						ps.setString(4, temp.getSection().toString());
						ps.setString(5, temp.getSubject());
						ps.setString(6, temp.getSchool());
						ps.executeUpdate();
					} catch (SQLException e) {
						try {
							e.printStackTrace();
							con.rollback();
							throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Some error occured in SQL");
						} catch (SQLException e1) {
							e1.printStackTrace();
							throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Rollback not performed");
						}
					}
				} else if (temp.getDay().equals(Day.TUESDAY)) {
					sql = "insert into edutize_timetable_tuesday (timetable_tuesday_facId,timetable_tuesday_period,timetable_tuesday_class,timetable_tuesday_section,timetable_tuesday_subject, school) values (?, ?, ?, ?, ?, ?)";
					try {
						con.setAutoCommit(false);
						ps = con.prepareStatement(sql);
						ps.setString(1, timetableWrapper.getFacId());
						ps.setString(2, temp.getPeriod().toString());
						ps.setString(3, temp.getClasses().toString());
						ps.setString(4, temp.getSection().toString());
						ps.setString(5, temp.getSubject());
						ps.setString(6, temp.getSchool());
						ps.executeUpdate();
					} catch (SQLException e) {
						try {
							e.printStackTrace();
							con.rollback();
							throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Some error occured in SQL");
						} catch (SQLException e1) {
							e1.printStackTrace();
							throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Rollback not performed");
						}

					}
				} else if (temp.getDay().equals(Day.WEDNESDAY)) {
					sql = "insert into edutize_timetable_wednesday (timetable_wednesday_facId,timetable_wednesday_period,timetable_wednesday_class,timetable_wednesday_section,timetable_wednesday_subject,school) values (?, ?, ?, ?, ?,?)";
					try {
						con.setAutoCommit(false);
						ps = con.prepareStatement(sql);
						ps.setString(1, timetableWrapper.getFacId());
						ps.setString(2, temp.getPeriod().toString());
						ps.setString(3, temp.getClasses().toString());
						ps.setString(4, temp.getSection().toString());
						ps.setString(5, temp.getSubject());
						ps.setString(6, temp.getSchool());
						ps.executeUpdate();
					} catch (SQLException e) {
						try {
							e.printStackTrace();
							con.rollback();
							throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Some error occured in SQL");
						} catch (SQLException e1) {
							e1.printStackTrace();
							throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Rollback not performed");
						}
					}
				} else if (temp.getDay().equals(Day.THRUSDAY)) {
					sql = "insert into edutize_timetable_thrusday (timetable_thrusday_facId,timetable_thrusday_period,timetable_thrusday_class,timetable_thrusday_section,timetable_thrusday_subject,school) values (?, ?, ?, ?,?,?)";
					try {
						con.setAutoCommit(false);
						ps = con.prepareStatement(sql);
						ps.setString(1, timetableWrapper.getFacId());
						ps.setString(2, temp.getPeriod().toString());
						ps.setString(3, temp.getClasses().toString());
						ps.setString(4, temp.getSection().toString());
						ps.setString(5, temp.getSubject());
						ps.setString(6, temp.getSchool());
						ps.executeUpdate();
					} catch (SQLException e) {
						try {
							e.printStackTrace();
							con.rollback();
							throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Some error occured in SQL");
						} catch (SQLException e1) {
							e1.printStackTrace();
							throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Rollback not performed");
						}
					}
				} else if (temp.getDay().equals(Day.FRIDAY)) {
					sql = "insert into edutize_timetable_friday (timetable_friday_facId,timetable_friday_period,timetable_friday_class,timetable_friday_section,timetable_friday_subject,school) values (?, ?, ?, ?, ?, ?)";
					try {
						con.setAutoCommit(false);
						ps = con.prepareStatement(sql);
						ps.setString(1, timetableWrapper.getFacId());
						ps.setString(2, temp.getPeriod().toString());
						ps.setString(3, temp.getClasses().toString());
						ps.setString(4, temp.getSection().toString());
						ps.setString(5, temp.getSubject());
						ps.setString(6, temp.getSchool());
						ps.executeUpdate();
					} catch (SQLException e) {
						try {
							e.printStackTrace();
							con.rollback();
							throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Some error occured in SQL");
						} catch (SQLException e1) {
							e1.printStackTrace();
							throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Rollback not performed");
						}
					}
				} else if (temp.getDay().equals(Day.SATURDAY)) {
					sql = "insert into edutize_timetable_saturday (timetable_saturday_facId,timetable_saturday_period,timetable_saturday_class,timetable_saturday_section,timetable_saturday_subject,school) values (?, ?, ?, ?, ?, ?)";
					try {
						con.setAutoCommit(false);
						ps = con.prepareStatement(sql);
						ps.setString(1, timetableWrapper.getFacId());
						ps.setString(2, temp.getPeriod().toString());
						ps.setString(3, temp.getClasses().toString());
						ps.setString(4, temp.getSection().toString());
						ps.setString(5, temp.getSubject());
						ps.setString(6, temp.getSchool());
						ps.executeUpdate();
					} catch (SQLException e) {
						try {
							e.printStackTrace();
							con.rollback();
							throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Some error occured in SQL");
						} catch (SQLException e1) {
							e1.printStackTrace();
							throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Rollback not performed");
						}
					}
				}
			}
		}
		try {
			con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new GenericException(Status.INTERNAL_SERVER_ERROR, "Not able to commit");
		}
		response.setSuccess(true);
		return response;
	}

	public List<Timetable> getTimetableForFaculty(String facId) {
		Connection con = null;
		PreparedStatement ps = null;
		String sql = null;
		ResultSet rs = null;

		List<Timetable> timetables = new ArrayList<Timetable>();
		Timetable timetable = null;
		con = DatabaseUtil.getConnection();
		if (con != null) {
			try {
				sql = "select * from edutize_timetable_monday where timetable_monday_facId = ?";
				ps = con.prepareStatement(sql);
				ps.setString(1, facId);
				rs = ps.executeQuery();
				while (rs.next()) {
					timetable = new Timetable();
					timetable.setDay(Day.MONDAY);
					timetable.setClasses(Classes.valueOf(rs.getString(4)));
					timetable.setSection(Section.valueOf(rs.getString(5)));
					timetable.setPeriod(Period.valueOf(rs.getString(3)));
					timetable.setSubject(rs.getString(6));
					timetables.add(timetable);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "SQL exception occurred");
			}
			try {
				sql = "select * from edutize_timetable_tuesday where timetable_tuesday_facId = ?";
				ps = con.prepareStatement(sql);
				ps.setString(1, facId);
				rs = ps.executeQuery();
				while (rs.next()) {
					timetable = new Timetable();
					timetable.setDay(Day.TUESDAY);
					timetable.setClasses(Classes.valueOf(rs.getString(4)));
					timetable.setSection(Section.valueOf(rs.getString(5)));
					timetable.setPeriod(Period.valueOf(rs.getString(3)));
					timetable.setSubject(rs.getString(6));
					timetables.add(timetable);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "SQL exception occurred");
			}
			try {
				sql = "select * from edutize_timetable_wednesday where timetable_wednesday_facId = ?";
				ps = con.prepareStatement(sql);
				ps.setString(1, facId);
				rs = ps.executeQuery();
				while (rs.next()) {
					timetable = new Timetable();
					timetable.setDay(Day.WEDNESDAY);
					timetable.setClasses(Classes.valueOf(rs.getString(4)));
					timetable.setSection(Section.valueOf(rs.getString(5)));
					timetable.setPeriod(Period.valueOf(rs.getString(3)));
					timetable.setSubject(rs.getString(6));
					timetables.add(timetable);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "SQL exception occurred");
			}
			try {
				sql = "select * from edutize_timetable_thrusday where timetable_thrusday_facId = ?";
				ps = con.prepareStatement(sql);
				ps.setString(1, facId);
				rs = ps.executeQuery();
				while (rs.next()) {
					timetable = new Timetable();
					timetable.setDay(Day.THRUSDAY);
					timetable.setClasses(Classes.valueOf(rs.getString(4)));
					timetable.setSection(Section.valueOf(rs.getString(5)));
					timetable.setPeriod(Period.valueOf(rs.getString(3)));
					timetable.setSubject(rs.getString(6));
					timetables.add(timetable);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "SQL exception occurred");
			}
			try {
				sql = "select * from edutize_timetable_friday where timetable_friday_facId = ?";
				ps = con.prepareStatement(sql);
				ps.setString(1, facId);
				rs = ps.executeQuery();
				while (rs.next()) {
					timetable = new Timetable();
					timetable.setDay(Day.FRIDAY);
					timetable.setClasses(Classes.valueOf(rs.getString(4)));
					timetable.setSection(Section.valueOf(rs.getString(5)));
					timetable.setPeriod(Period.valueOf(rs.getString(3)));
					timetable.setSubject(rs.getString(6));
					timetables.add(timetable);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "SQL exception occurred");
			}
			try {
				sql = "select * from edutize_timetable_saturday where timetable_saturday_facId = ?";
				ps = con.prepareStatement(sql);
				ps.setString(1, facId);
				rs = ps.executeQuery();
				while (rs.next()) {
					timetable = new Timetable();
					timetable.setDay(Day.SATURDAY);
					timetable.setClasses(Classes.valueOf(rs.getString(4)));
					timetable.setSection(Section.valueOf(rs.getString(5)));
					timetable.setPeriod(Period.valueOf(rs.getString(3)));
					timetable.setSubject(rs.getString(6));
					timetables.add(timetable);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "SQL exception occurred");
			}
		}
		return timetables;
	}

	public List<Timetable> getTimetableForStudent(String school, String classes, String section) {
		Connection con = null;
		PreparedStatement ps = null;
		String sql = null;
		ResultSet rs = null;

		List<Timetable> timetables = new ArrayList<Timetable>();
		Timetable timetable = null;
		con = DatabaseUtil.getConnection();
		if (con != null) {

			try {
				sql = "select * from edutize_timetable_monday where school = ? and timetable_monday_class=? and timetable_monday_section=?";
				ps = con.prepareStatement(sql);
				ps.setString(1, school);
				ps.setString(2, classes);
				ps.setString(3, section);
				rs = ps.executeQuery();
				while (rs.next()) {
					timetable = new Timetable();
					timetable.setDay(Day.MONDAY);
					timetable.setClasses(Classes.valueOf(classes));
					timetable.setSection(Section.valueOf(section));
					timetable.setPeriod(Period.valueOf(rs.getString(3)));
					timetable.setSubject(rs.getString(6));
					timetable.setFacultyId(rs.getString(2));
					timetables.add(timetable);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "SQL exception occurred");
			}
			try {
				sql = "select * from edutize_timetable_tuesday where school = ? and timetable_tuesday_class=? and timetable_tuesday_section=?";
				ps = con.prepareStatement(sql);
				ps.setString(1, school);
				ps.setString(2, classes);
				ps.setString(3, section);
				rs = ps.executeQuery();
				while (rs.next()) {
					timetable = new Timetable();
					timetable.setDay(Day.TUESDAY);
					timetable.setClasses(Classes.valueOf(classes));
					timetable.setSection(Section.valueOf(section));
					timetable.setPeriod(Period.valueOf(rs.getString(3)));
					timetable.setSubject(rs.getString(6));
					timetable.setFacultyId(rs.getString(2));
					timetables.add(timetable);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "SQL exception occurred");
			}
			try {
				sql = "select * from edutize_timetable_wednesday where school = ? and timetable_wednesday_class=? and timetable_wednesday_section=?";
				ps = con.prepareStatement(sql);
				ps.setString(1, school);
				ps.setString(2, classes);
				ps.setString(3, section);
				rs = ps.executeQuery();
				while (rs.next()) {
					timetable = new Timetable();
					timetable.setDay(Day.WEDNESDAY);
					timetable.setClasses(Classes.valueOf(classes));
					timetable.setSection(Section.valueOf(section));
					timetable.setPeriod(Period.valueOf(rs.getString(3)));
					timetable.setSubject(rs.getString(6));
					timetable.setFacultyId(rs.getString(2));
					timetables.add(timetable);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "SQL exception occurred");
			}
			try {
				sql = "select * from edutize_timetable_thrusday where school = ? and timetable_thrusday_class=? and timetable_thrusday_section=?";
				ps = con.prepareStatement(sql);
				ps.setString(1, school);
				ps.setString(2, classes);
				ps.setString(3, section);
				rs = ps.executeQuery();
				while (rs.next()) {
					timetable = new Timetable();
					timetable.setDay(Day.THRUSDAY);
					timetable.setClasses(Classes.valueOf(classes));
					timetable.setSection(Section.valueOf(section));
					timetable.setPeriod(Period.valueOf(rs.getString(3)));
					timetable.setSubject(rs.getString(6));
					timetable.setFacultyId(rs.getString(2));
					timetables.add(timetable);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "SQL exception occurred");
			}
			try {
				sql = "select * from edutize_timetable_friday where school = ? and timetable_friday_class=? and timetable_friday_section=?";
				ps = con.prepareStatement(sql);
				ps.setString(1, school);
				ps.setString(2, classes);
				ps.setString(3, section);
				rs = ps.executeQuery();
				while (rs.next()) {
					timetable = new Timetable();
					timetable.setDay(Day.FRIDAY);
					timetable.setClasses(Classes.valueOf(classes));
					timetable.setSection(Section.valueOf(section));
					timetable.setPeriod(Period.valueOf(rs.getString(3)));
					timetable.setSubject(rs.getString(6));
					timetable.setFacultyId(rs.getString(2));
					timetables.add(timetable);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "SQL exception occurred");
			}
			try {
				sql = "select * from edutize_timetable_saturday where school = ? and timetable_saturday_class=? and timetable_saturday_section=?";
				ps = con.prepareStatement(sql);
				ps.setString(1, school);
				ps.setString(2, classes);
				ps.setString(3, section);
				rs = ps.executeQuery();
				while (rs.next()) {
					timetable = new Timetable();
					timetable.setDay(Day.SATURDAY);
					timetable.setClasses(Classes.valueOf(classes));
					timetable.setSection(Section.valueOf(section));
					timetable.setPeriod(Period.valueOf(rs.getString(3)));
					timetable.setSubject(rs.getString(6));
					timetable.setFacultyId(rs.getString(2));
					timetables.add(timetable);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new GenericException(Status.BAD_REQUEST, "SQL exception occurred");
			}
		}
		return timetables;
	}

}
