package com.edutize.en.timetable.service;

import java.util.List;

import com.edutize.en.timetable.dao.TimetableDao;
import com.edutize.en.timetable.dto.Timetable;
import com.edutize.en.timetable.dto.TimetableResponse;
import com.edutize.en.timetable.dto.TimetableWrapper;

public class TimetableService {

	public TimetableResponse toService(TimetableWrapper timetableWrapper) {
		TimetableDao dao = new TimetableDao();
		TimetableResponse response = dao.toDao(timetableWrapper);
		return response;
	}

	public List<Timetable> getTimetableForFaculty(String facId) {
		TimetableDao dao = new TimetableDao();
		List<Timetable> timetables = dao.getTimetableForFaculty(facId);
		return timetables;
	}

	public List<Timetable> getTimetableForStudent(String school, String classes, String section) {
		TimetableDao dao = new TimetableDao();
		List<Timetable> timetables = dao.getTimetableForStudent(school, classes, section);
		return timetables;
	}

}
