package com.edutize.en.timetable.dto;

import com.edutize.en.classnsection.Classes;
import com.edutize.en.classnsection.Period;
import com.edutize.en.classnsection.Section;
import com.edutize.en.profile.Day;

public class Timetable {

	private Day day;
	private Period period;
	private Classes classes;
	private Section section;
	private String subject;
	private String facultyId;
	private String school;

	public Day getDay() {
		return day;
	}

	public void setDay(Day day) {
		this.day = day;
	}

	public Period getPeriod() {
		return period;
	}

	public void setPeriod(Period period) {
		this.period = period;
	}

	public Classes getClasses() {
		return classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	public Section getSection() {
		return section;
	}

	public void setSection(Section section) {
		this.section = section;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getFacultyId() {
		return facultyId;
	}

	public void setFacultyId(String facultyId) {
		this.facultyId = facultyId;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

}
