package com.edutize.en.timetable.dto;

public class TimetableResponseWrapper {

	private TimetableResponse timetableResponse = new TimetableResponse();

	public TimetableResponse getTimetableResponse() {
		return timetableResponse;
	}

	public void setTimetableResponse(TimetableResponse timetableResponse) {
		this.timetableResponse = timetableResponse;
	}

}
