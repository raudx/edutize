package com.edutize.en.timetable.restweb;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.edutize.en.timetable.dto.Timetable;
import com.edutize.en.timetable.dto.TimetableResponse;
import com.edutize.en.timetable.dto.TimetableResponseWrapper;
import com.edutize.en.timetable.dto.TimetableWrapper;
import com.edutize.en.timetable.service.TimetableService;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("/")
public class TimeatbleResource {

	/**
	 * Method handling HTTP GET requests. The returned object will be sent to
	 * the client as "text/plain" media type.
	 *
	 * @return String that will be returned as a text/plain response.
	 */
	@PUT
	@Path("/create")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public TimetableResponseWrapper createTimetable(TimetableWrapper timetableWrapper) {
		TimetableResponseWrapper responseWrapper = new TimetableResponseWrapper();
		TimetableService timetableService = new TimetableService();
		TimetableResponse response = timetableService.toService(timetableWrapper);
		responseWrapper.setTimetableResponse(response);
		return responseWrapper;

	}

	@GET
	@Path("faculty/{facId}")
	@Produces(MediaType.APPLICATION_JSON)
	public TimetableWrapper getTimetableForFaculty(@PathParam("facId") String facId) {
		TimetableWrapper timetableWrapper = new TimetableWrapper();
		TimetableService service = new TimetableService();
		List<Timetable> timetable = service.getTimetableForFaculty(facId);
		timetableWrapper.setFacId(facId);
		timetableWrapper.setTimetable(timetable);
		return timetableWrapper;

	}

	@GET
	@Path("class")
	@Produces(MediaType.APPLICATION_JSON)
	public TimetableWrapper getTimetableForFaculty(@QueryParam("school") String school,
			@QueryParam("class") String classes, @QueryParam("section") String section) {
		TimetableWrapper timetableWrapper = new TimetableWrapper();
		TimetableService service = new TimetableService();
		List<Timetable> timetables = service.getTimetableForStudent(school, classes, section);
		timetableWrapper.setFacId(null);
		timetableWrapper.setTimetable(timetables);
		return timetableWrapper;
	}
}
